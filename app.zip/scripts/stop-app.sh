#!/bin/sh
cd /home/ec2-user/sketchbox-api
forever stop index.js || exit 0